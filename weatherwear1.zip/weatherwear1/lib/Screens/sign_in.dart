import 'package:flutter/material.dart';

class SignInScreen extends StatefulWidget {
  @override
  _SignInScreenState createState() => _SignInScreenState();
}

class _SignInScreenState extends State<SignInScreen> {
  int _currentStep = 0;

  // Step 1: Text controllers
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();

  // Step 2: Gender, Age, City
  String? _selectedGender;
  final TextEditingController _ageController = TextEditingController();
  String? _selectedCity;

  // Step 3: Style
  String? _selectedStyle;

  // Form key for Step 1 validation
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFFF1EFE7), // Arka plan rengi
      appBar: AppBar(
        backgroundColor: Colors.black, // AppBar arka planı siyah
        title: Text(
          'Register',
          style: TextStyle(color: Colors.white), // Yazı rengi beyaz
        ),
        iconTheme: IconThemeData(color: Colors.white), // Back butonunu beyaz yapar
      ),
      body: Stack(
        children: [
          // Progress bar ve içerik
          Column(
            children: [
              // Progress bar
              LinearProgressIndicator(
                value: (_currentStep + 1) / 3,
                color: Colors.teal,
                backgroundColor: Colors.teal[100],
              ),
              SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'Step ${_currentStep + 1}/3',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
              SizedBox(height: 40),

              // Dynamic content for each step
              Expanded(
                child: Container(
                  alignment: Alignment.center,
                  child: _buildStepContent(_currentStep),
                ),
              ),
            ],
          ),

          // Sabit pozisyonlu butonlar
          Positioned(
            bottom: 20,
            left: 20,
            child: Visibility(
              visible: _currentStep > 0,
              child: ElevatedButton(
                onPressed: () {
                  setState(() {
                    _currentStep--;
                  });
                },
                child: Text('Back'),
              ),
            ),
          ),
          Positioned(
            bottom: 20,
            right: 20,
            child: ElevatedButton(
              onPressed: () {
                if (_currentStep == 0) {
                  if (_formKey.currentState!.validate()) {
                    setState(() {
                      _currentStep++;
                    });
                  }
                } else if (_currentStep == 1) {
                  if (_selectedGender != null &&
                      _ageController.text.isNotEmpty &&
                      _selectedCity != null) {
                    if (int.tryParse(_ageController.text) != null &&
                        int.parse(_ageController.text) > 120) {
                      _showAgeErrorDialog(context);
                    } else {
                      setState(() {
                        _currentStep++;
                      });
                    }
                  } else {
                    _showErrorDialog(context, "Please fill out all the fields (Gender, Age, and City).");
                  }
                } else if (_currentStep == 2) {
                  if (_selectedStyle != null) {
                    print("Registration Complete");
                  } else {
                    _showErrorDialog(context, "Please select a style to complete registration.");
                  }
                }
              },
              child: Text(_currentStep < 2 ? 'Next' : 'Complete'),
            ),
          ),
        ],
      ),
    );
  }

  // Content for each step
  Widget _buildStepContent(int step) {
    switch (step) {
      case 0:
        return Padding(
          padding: const EdgeInsets.all(16.0),
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Name Input Field
                TextFormField(
                  controller: _nameController,
                  decoration: InputDecoration(
                    labelText: 'Name',
                    hintText: 'Enter your name',
                    border: OutlineInputBorder(),
                  ),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Name cannot be empty';
                    }
                    return null;
                  },
                ),
                SizedBox(height: 20),

                // Email Input Field
                TextFormField(
                  controller: _emailController,
                  decoration: InputDecoration(
                    labelText: 'Email Address',
                    hintText: 'Enter your email address',
                    border: OutlineInputBorder(),
                  ),
                  keyboardType: TextInputType.emailAddress,
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Email cannot be empty';
                    } else if (!RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(value)) {
                      return 'Enter a valid email address';
                    }
                    return null;
                  },
                ),
              ],
            ),
          ),
        );
      case 1:
        return Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                "We'd like to know you better...",
                style: TextStyle(fontSize: 18),
              ),
              SizedBox(height: 20),

              // Gender Dropdown
              DropdownButtonFormField<String>(
                value: _selectedGender,
                items: ['Male', 'Female']
                    .map((gender) =>
                        DropdownMenuItem(value: gender, child: Text(gender)))
                    .toList(),
                onChanged: (value) {
                  setState(() {
                    _selectedGender = value;
                  });
                },
                decoration: InputDecoration(
                  labelText: 'Gender',
                  border: OutlineInputBorder(),
                ),
              ),
              SizedBox(height: 20),

              // Age Input Field
              TextField(
                controller: _ageController,
                decoration: InputDecoration(
                  labelText: 'Age',
                  hintText: 'Enter your age',
                  border: OutlineInputBorder(),
                ),
                keyboardType: TextInputType.number,
              ),
              SizedBox(height: 20),

              // City Dropdown
              DropdownButtonFormField<String>(
                value: _selectedCity,
                items: [
                  'İstanbul',
                  'Ankara',
                  'İzmir',
                  'Aydın',
                  'Adana',
                  'Antalya',
                  'Balıkesir',
                  'Bursa',
                  'Çanakkale',
                  'Edirne',
                  'Eskişehir',
                  'Gaziantep',
                  'Kocaeli',
                  'Manisa',
                  'Muğla',
                  'Samsun',
                  'Sivas',
                  'Yalova',
                  'Zonguldak',
                ]
                    .map((city) =>
                        DropdownMenuItem(value: city, child: Text(city)))
                    .toList(),
                onChanged: (value) {
                  setState(() {
                    _selectedCity = value;
                  });
                },
                decoration: InputDecoration(
                  labelText: 'City',
                  border: OutlineInputBorder(),
                ),
              ),
            ],
          ),
        );
      case 2:
        return Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                "To give you recommendations, we'd like to know your daily style.",
                style: TextStyle(fontSize: 18),
              ),
              SizedBox(height: 20),

              // Style Dropdown
              DropdownButtonFormField<String>(
                value: _selectedStyle,
                items: ['Casual', 'Stylish', 'Sportive', 'Business']
                    .map((style) =>
                        DropdownMenuItem(value: style, child: Text(style)))
                    .toList(),
                onChanged: (value) {
                  setState(() {
                    _selectedStyle = value;
                  });
                },
                decoration: InputDecoration(
                  labelText: 'Style',
                  border: OutlineInputBorder(),
                ),
              ),
            ],
          ),
        );
      default:
        return Container();
    }
  }

  // Show error dialog
  void _showErrorDialog(BuildContext context, String message) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Incomplete Information'),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.of(ctx).pop();
            },
            child: Text('OK'),
          ),
        ],
      ),
    );
  }

  // Show age error dialog
  void _showAgeErrorDialog(BuildContext context) {
    _showErrorDialog(context, "We want you to enter a valid age, please.");
  }

  @override
  void dispose() {
    // Cleanup text controllers
    _nameController.dispose();
    _emailController.dispose();
    _ageController.dispose();
    super.dispose();
  }
}