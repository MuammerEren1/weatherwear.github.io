import 'package:flutter/material.dart';
import 'screens/sign_in.dart'; // SignIn ekranını içe aktarıyoruz.

void main() {
  runApp(WeatherWearApp());
}

class WeatherWearApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: WelcomeScreen(),
    );
  }
}

class WelcomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromARGB(255, 240, 239, 234), // Arka plan rengi
      appBar: AppBar(
        backgroundColor: Colors.black, // AppBar arka planı siyah
        title: Text(
          'WeatherWear',
          style: TextStyle(color: Colors.white), // Yazı rengi beyaz
        ),
        centerTitle: true,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Welcome Text
            Text(
              'Welcome to WeatherWear!',
              style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 20), // Resimle yazı arasındaki boşluk

            // WeatherWear Logo
            Container(
              width: 420, // Genişlik (arttırıldı)
              height: 250, // Yükseklik (arttırıldı)
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage('assets/images/weatherwear_logo2.png'), // Resim yolu
                  fit: BoxFit.cover, // Resmi Container'a sığdır
                ),
              ),
            ),
            SizedBox(height: 20), // Logo ile açıklama arasındaki boşluk

            // Description Text
            Text(
              'WeatherWear helps you stay comfortable daily\nbased on the weather conditions.',
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16),
            ),
            SizedBox(height: 20),

            // Sign In Button
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => SignInScreen()),
                );
              },
              child: Text('Sign In'),
            ),
          ],
        ),
      ),
    );
  }
}